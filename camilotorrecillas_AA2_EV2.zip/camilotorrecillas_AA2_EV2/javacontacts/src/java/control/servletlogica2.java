package control;

import java.sql.*;
import conexion.conexionDB;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "servletlogica2", urlPatterns = {"/servletlogica2"})
public class servletlogica2 extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");

        // Obtener parámetros del formulario
        String nombre = request.getParameter("nombre");
        String telefono = request.getParameter("telefono");
        String email = request.getParameter("email");
        String url = request.getParameter("url");
        String id2 = request.getParameter("id");

        
        conexionDB conec = new conexionDB();
        
        
        try (Connection conectar = conec.conectarDB()) {

            String sql = "UPDATE contactos SET nombre = ?, telefono = ?, email = ?, url = ? WHERE id = ?";

            try (PreparedStatement pst = conectar.prepareStatement(sql)) {
                pst.setString(1, nombre);
                pst.setString(2, telefono);
                pst.setString(3, email);
                pst.setString(4, url);
                pst.setString(5, id2);
                pst.executeUpdate();

                
                response.sendRedirect("index.jsp");
            }

        } catch (Exception e) {
            e.printStackTrace(); // Mejor que usar System.err
            response.getWriter().println("<h2>Error al guardar el contacto: " + e.getMessage() + "</h2>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet para modificar contactos";
    }
}

