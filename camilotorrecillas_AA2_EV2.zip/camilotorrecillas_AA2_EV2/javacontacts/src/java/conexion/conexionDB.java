
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conexionDB {

    Connection conectar = null;

    public Connection conectarDB() {
        try {
            // Cargar el driver correcto de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // URL de conexión: localhost, puerto 3306, base agendadecontactos
            conectar = DriverManager.getConnection(
                "jdbc:mysql://127.0.0.1:3306/agendadecontactos?useSSL=false&serverTimezone=UTC", 
                "root", 
                "BaseDeDatos555"
            );

        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Error de conexión: " + e.getMessage());
        }

        return conectar;
    }
}
